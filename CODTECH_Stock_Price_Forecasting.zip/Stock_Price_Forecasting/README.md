# Stock Price Forecasting — CODTECH Project

This Python project demonstrates time-series forecasting of daily stock closing prices using historical market data and an LSTM neural network when TensorFlow is installed. It also includes a dependable baseline forecast based on a moving average so the project can run without deep-learning packages.

## Files
- `stock_price_forecasting.py` — data loading, exploratory charts, baseline forecast, optional LSTM forecast, and metrics.
- `sample_stock_data.csv` — illustrative sample data for immediate testing.
- `requirements.txt` — core dependencies (TensorFlow is optional).
- `CODTECH_Stock_Price_Forecasting_Report.md` — report template.
- `outputs/` — generated charts, predictions, and metrics after execution.

## Run
1. Install Python 3.10 or newer.
2. Extract the ZIP and open the folder in VS Code.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python stock_price_forecasting.py
   ```
5. Open the generated `outputs/` folder.

## Use actual stock data
For meaningful work, replace the sample data with an authorized historical dataset saved as `stock_data.csv`, with at least a `Date` column and a `Close` column. The script will prefer `stock_data.csv` if present. Data may also use `Adj Close` or `Closing Price` for the close field.

You can export daily historical data from a permitted market-data source and place the CSV in this folder. Check your CODTECH task instructions for a required ticker, period, or dataset source.

## Important limitations
- The included sample data is synthetic/illustrative and is not a real market quote series.
- Stock forecasts are uncertain and can be inaccurate, especially around news, earnings, and market shocks.
- Model outputs are for educational use only, not investment advice.
- The optional LSTM model needs TensorFlow; if TensorFlow is unavailable or the dataset is too small, the script still creates a moving-average baseline forecast.
