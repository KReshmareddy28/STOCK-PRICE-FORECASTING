"""
Stock Price Forecasting — CODTECH project
Uses historical closing prices, a moving-average baseline, and optional LSTM.
Run: python stock_price_forecasting.py
"""
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error, mean_squared_error

warnings.filterwarnings("ignore", category=FutureWarning)
ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "outputs"
OUTPUT.mkdir(exist_ok=True)


def load_data():
    real_path = ROOT / "stock_data.csv"
    sample_path = ROOT / "sample_stock_data.csv"
    path = real_path if real_path.exists() else sample_path
    df = pd.read_csv(path)
    df.columns = [str(c).strip() for c in df.columns]
    date_col = next((c for c in df.columns if c.lower() in {"date", "datetime", "timestamp"}), None)
    close_col = next((c for c in df.columns if c.lower() in {"close", "adj close", "closing price", "close_price"}), None)
    if date_col is None or close_col is None:
        raise ValueError("CSV must include a Date column and a Close (or Adj Close/Closing Price) column.")
    df = df[[date_col, close_col]].rename(columns={date_col: "Date", close_col: "Close"})
    df["Date"] = pd.to_datetime(df["Date"], errors="coerce")
    df["Close"] = pd.to_numeric(df["Close"], errors="coerce")
    df = df.dropna().sort_values("Date").drop_duplicates("Date").reset_index(drop=True)
    if len(df) < 20:
        raise ValueError("Please provide at least 20 valid daily observations.")
    print(f"Loaded {len(df)} rows from {path.name}")
    return df


def evaluate_baseline(df):
    values = df["Close"].to_numpy(dtype=float)
    dates = df["Date"].to_numpy()
    # Chronological holdout: last 20% of observations.
    split = max(int(len(values) * 0.8), 10)
    split = min(split, len(values) - 5)
    train, test = values[:split], values[split:]
    predictions = []
    history = list(train)
    window = min(5, len(history))
    for actual in test:
        predictions.append(float(np.mean(history[-window:])))
        history.append(float(actual))
    predictions = np.array(predictions)
    mae = mean_absolute_error(test, predictions)
    rmse = float(np.sqrt(mean_squared_error(test, predictions)))
    mape = float(np.mean(np.abs((test - predictions) / np.maximum(np.abs(test), 1e-8))) * 100)

    pred_df = pd.DataFrame({
        "Date": pd.to_datetime(dates[split:]),
        "Actual_Close": test,
        "Predicted_Close_Moving_Average": predictions,
    })
    pred_df.to_csv(OUTPUT / "test_predictions.csv", index=False)

    metrics = [
        ("Observations", len(values)),
        ("Training observations", len(train)),
        ("Test observations", len(test)),
        ("MAE", round(float(mae), 4)),
        ("RMSE", round(rmse, 4)),
        ("MAPE_percent", round(mape, 3)),
    ]
    pd.DataFrame(metrics, columns=["Metric", "Value"]).to_csv(OUTPUT / "model_metrics.csv", index=False)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df["Date"], df["Close"], label="Historical closing price")
    ax.axvline(df["Date"].iloc[split], linestyle="--", label="Train/test split")
    ax.set_title("Historical Stock Closing Prices")
    ax.set_xlabel("Date")
    ax.set_ylabel("Closing price")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUTPUT / "historical_close_prices.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(pred_df["Date"], pred_df["Actual_Close"], marker="o", label="Actual close")
    ax.plot(pred_df["Date"], pred_df["Predicted_Close_Moving_Average"], marker="x", label="Moving-average forecast")
    ax.set_title("Test Set: Actual vs Predicted Closing Prices")
    ax.set_xlabel("Date")
    ax.set_ylabel("Closing price")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUTPUT / "actual_vs_predicted.png", dpi=160)
    plt.close(fig)

    # Recursive future baseline forecast: each next value uses recent history.
    future_steps = 5
    hist = list(values)
    last_date = pd.to_datetime(df["Date"].iloc[-1])
    future_rows = []
    window = min(5, len(hist))
    for step in range(1, future_steps + 1):
        forecast = float(np.mean(hist[-window:]))
        hist.append(forecast)
        future_rows.append({
            "Forecast_Step": step,
            "Forecast_Date": last_date + pd.offsets.BDay(step),
            "Forecast_Close_Moving_Average": round(forecast, 4),
        })
    future_df = pd.DataFrame(future_rows)
    future_df.to_csv(OUTPUT / "future_forecast.csv", index=False)

    fig, ax = plt.subplots(figsize=(10, 5))
    recent = df.tail(min(25, len(df)))
    ax.plot(recent["Date"], recent["Close"], marker="o", label="Recent historical close")
    ax.plot(future_df["Forecast_Date"], future_df["Forecast_Close_Moving_Average"],
            marker="x", linestyle="--", label="Illustrative 5-business-day forecast")
    ax.set_title("Illustrative Future Forecast (Moving-Average Baseline)")
    ax.set_xlabel("Date")
    ax.set_ylabel("Closing price")
    ax.legend()
    fig.tight_layout()
    fig.savefig(OUTPUT / "future_forecast.png", dpi=160)
    plt.close(fig)

    print("\nMoving-average baseline metrics:")
    for name, value in metrics:
        print(f"{name}: {value}")
    print("\nIllustrative next five business-day forecast:")
    print(future_df.to_string(index=False))
    return df, train, test, predictions


def try_lstm(df):
    """Optional LSTM model; skips cleanly if TensorFlow is not installed."""
    try:
        from sklearn.preprocessing import MinMaxScaler
        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import LSTM, Dense
    except Exception:
        print("\nTensorFlow is not installed; skipping optional LSTM model.")
        print("The moving-average baseline has completed successfully.")
        return

    values = df["Close"].to_numpy(dtype=float).reshape(-1, 1)
    if len(values) < 40:
        print("\nNot enough observations for a useful LSTM demonstration; skipping LSTM.")
        return

    scaler = MinMaxScaler()
    scaled = scaler.fit_transform(values)
    lookback = 10
    X, y = [], []
    for i in range(lookback, len(scaled)):
        X.append(scaled[i-lookback:i, 0])
        y.append(scaled[i, 0])
    X, y = np.array(X), np.array(y)
    X = X.reshape((X.shape[0], X.shape[1], 1))
    split = max(int(len(X) * 0.8), 10)
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]
    if len(X_test) == 0:
        print("Insufficient test samples for LSTM evaluation.")
        return

    model = Sequential([
        LSTM(32, input_shape=(lookback, 1)),
        Dense(1),
    ])
    model.compile(optimizer="adam", loss="mean_squared_error")
    model.fit(X_train, y_train, epochs=20, batch_size=8, verbose=0, shuffle=False)
    pred_scaled = model.predict(X_test, verbose=0)
    pred = scaler.inverse_transform(pred_scaled).ravel()
    actual = scaler.inverse_transform(y_test.reshape(-1, 1)).ravel()
    mae = mean_absolute_error(actual, pred)
    rmse = np.sqrt(mean_squared_error(actual, pred))
    pd.DataFrame({"Actual_Close": actual, "LSTM_Predicted_Close": pred}).to_csv(
        OUTPUT / "lstm_test_predictions.csv", index=False
    )
    with open(OUTPUT / "lstm_metrics.txt", "w", encoding="utf-8") as f:
        f.write(f"LSTM MAE: {mae:.4f}\nLSTM RMSE: {rmse:.4f}\n")
    print(f"\nOptional LSTM metrics: MAE={mae:.4f}, RMSE={rmse:.4f}")


def main():
    df = load_data()
    print("\nDataset preview:")
    print(df.head().to_string(index=False))
    print(f"\nDate range: {df['Date'].min().date()} to {df['Date'].max().date()}")
    print(f"Latest closing price in dataset: {df['Close'].iloc[-1]:.4f}")
    evaluate_baseline(df)
    try_lstm(df)
    print(f"\nDone. Generated files are in: {OUTPUT}")
    print("Use actual historical data for meaningful evaluation. Forecasts are educational only.")


if __name__ == "__main__":
    main()
